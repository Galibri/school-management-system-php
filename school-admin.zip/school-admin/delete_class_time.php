<?php
require_once '../functions.php';

if(isset($_POST['id'])) {
	$id = $_POST['id'];
	$query = "DELETE FROM classtime WHERE id=$id";
	$result = mysqli_query($conn, $query);

	if($result) {
		return true;
	}
}