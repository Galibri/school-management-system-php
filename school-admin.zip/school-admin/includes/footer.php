						</div>
					</div><!-- /.row -->
				</div><!-- /#page-wrapper -->
			</div><!-- /#wrapper -->
			<!-- JavaScript -->
			<script src="js/bootstrap.js"></script>
			<script src="js/bootstrap-datepicker1.js"></script>
			<script src='js/tinymce.min.js'></script>
			<script src='js/custom.js'></script>
		</body>
	</html>